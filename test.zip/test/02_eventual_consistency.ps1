. "$PSScriptRoot/common.ps1"

$poll = "test_eventual"

Print-Step "Stop node3"
docker compose -f docker-compose.generated.yml stop node3

Print-Step "Send votes while node3 is down"
Vote 1 $poll "A"
Vote 2 $poll "B"
Vote 1 $poll "A"

Print-Step "Restart node3"
docker compose -f docker-compose.generated.yml start node3

Print-Step "Wait for convergence on all nodes"
$snapshots = Wait-UntilAllNodesPollCounts @(1, 2, 3) $poll 2 1 45

$snapshots.GetEnumerator() | ForEach-Object {
    [PSCustomObject]@{
        node = "$($_.Key)"
        response = $_.Value
    }
} | ConvertTo-Json -Depth 10

Print-Ok "Eventual consistency after rejoin works"