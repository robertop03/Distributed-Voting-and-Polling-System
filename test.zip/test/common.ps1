$ProxyBase = "http://localhost:18080"

function Get-NodeBaseUrl($nodeId) {
    return "$ProxyBase/node/$nodeId"
}

function Vote($nodeId, $poll, $option) {
    Invoke-RestMethod -Method POST "$(Get-NodeBaseUrl $nodeId)/vote" `
        -ContentType "application/json" `
        -Body "{""poll_id"":""$poll"",""option"":""$option""}"
}

function Get-Poll($nodeId, $poll) {
    Invoke-RestMethod "$(Get-NodeBaseUrl $nodeId)/poll/$poll"
}

function Get-Status($nodeId) {
    Invoke-RestMethod "$(Get-NodeBaseUrl $nodeId)/status"
}

function Get-Status_With-URL($url) {
    return Invoke-RestMethod -Uri "$url/status" -Method Get
}

function Get-InternalBaseUrl($port) {
    return "http://localhost:$port"
}

function Post-InternalUpdate($port, $updateObj, $headers = @{}) {
    Invoke-RestMethod -Method POST "$(Get-InternalBaseUrl $port)/internal/counter/update" `
        -ContentType "application/json" `
        -Headers $headers `
        -Body ($updateObj | ConvertTo-Json)
}

function Wait-Seconds($s) {
    Start-Sleep -Seconds $s
}

function Print-Step($msg) {
    Write-Host "`n=== $msg ===" -ForegroundColor Cyan
}

function Print-Ok($msg) {
    Write-Host "[OK] $msg" -ForegroundColor Green
}

function Get-CountValue($counts, $key) {
    if ($null -eq $counts) {
        return 0
    }

    $prop = $counts.PSObject.Properties[$key]
    if ($null -eq $prop) {
        return 0
    }

    return [int]$prop.Value
}

function Wait-UntilPollCounts($nodeId, $poll, $expectedA, $expectedB, $timeoutSec = 25) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    $last = $null

    while ((Get-Date) -lt $deadline) {
        try {
            $r = Get-Poll $nodeId $poll
            $last = $r

            $a = Get-CountValue $r.counts "A"
            $b = Get-CountValue $r.counts "B"

            Write-Host "Waiting on node $nodeId -> current counts: A=$a B=$b"

            if ($a -eq $expectedA -and $b -eq $expectedB) {
                return $r
            }
        }
        catch {
            Write-Host "Waiting on node $nodeId -> node not reachable yet"
        }

        Start-Sleep -Seconds 1
    }

    if ($null -ne $last) {
        $lastJson = $last | ConvertTo-Json -Depth 10
        throw "Timeout waiting for poll '$poll' on node $nodeId to reach A=$expectedA, B=$expectedB. Last response: $lastJson"
    }

    throw "Timeout waiting for poll '$poll' on node $nodeId to reach A=$expectedA, B=$expectedB. No successful response received."
}

function Wait-UntilAllNodesPollCounts($nodeIds, $poll, $expectedA, $expectedB, $timeoutSec = 40) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    $lastSnapshots = @{}

    while ((Get-Date) -lt $deadline) {
        $allOk = $true

        foreach ($nodeId in $nodeIds) {
            try {
                $r = Get-Poll $nodeId $poll
                $lastSnapshots[$nodeId] = $r

                $a = Get-CountValue $r.counts "A"
                $b = Get-CountValue $r.counts "B"

                Write-Host "Node $nodeId -> A=$a B=$b"

                if ($a -ne $expectedA -or $b -ne $expectedB) {
                    $allOk = $false
                }
            }
            catch {
                Write-Host "Node $nodeId -> not reachable yet"
                $allOk = $false
            }
        }

        if ($allOk) {
            return $lastSnapshots
        }

        Start-Sleep -Seconds 1
    }

    $snapshotsJson = $lastSnapshots | ConvertTo-Json -Depth 10
    throw "Timeout waiting for all nodes to reach A=$expectedA, B=$expectedB for poll '$poll'. Last snapshots: $snapshotsJson"
}

function Get-PeerState($statusObj, $peerName) {
    foreach ($p in $statusObj.peers) {
        if ($p.peer -like "*$peerName*") {
            return $p.state
        }
    }
    return $null
}

function Wait-ForPeerState($observerUrl, $peerName, $expectedStates, $timeoutSec = 20, $intervalSec = 1) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            $status = Get-Status_With-URL $observerUrl
            $state = Get-PeerState $status $peerName
            Write-Host "[INFO] Observed state for $peerName from $observerUrl => $state"

            if ($null -ne $state -and $expectedStates -contains $state) {
                return $true
            }
        } catch {
            Write-Host "[WARN] Failed to query $observerUrl/status : $_"
        }

        Start-Sleep -Seconds $intervalSec
    }

    return $false
}

function Get-CountsAB($nodeId, $poll) {
    $r = Get-Poll $nodeId $poll
    return [PSCustomObject]@{
        A = Get-CountValue $r.counts "A"
        B = Get-CountValue $r.counts "B"
        Raw = $r
    }
}

function Wait-HttpReady($nodeId, $timeoutSec = 30) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            Invoke-RestMethod -Method GET "$(Get-NodeBaseUrl $nodeId)/status" -TimeoutSec 2 | Out-Null
            return
        } catch {
            Start-Sleep -Seconds 1
        }
    }

    throw "Service for node $nodeId did not become ready within $timeoutSec seconds"
}

function Wait-ProxyReady($timeoutSec = 30) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            Invoke-RestMethod -Method GET "$ProxyBase/" -TimeoutSec 2 | Out-Null
            return
        } catch {
            Start-Sleep -Seconds 1
        }
    }

    throw "Proxy did not become ready within $timeoutSec seconds"
}

function Import-Env {
    param(
        [string]$Path = ".env"
    )

    if (-not (Test-Path $Path)) {
        Write-Warning ".env file not found at $Path"
        return
    }

    Get-Content $Path | ForEach-Object {
        $line = $_.Trim()

        if (-not $line) { return }
        if ($line.StartsWith("#")) { return }
        if ($line -notmatch "=") { return }

        $key, $value = $line -split "=", 2
        $key = $key.Trim()
        $value = $value.Trim()

        [System.Environment]::SetEnvironmentVariable($key, $value, "Process")
    }
}

function Get-NodeBaseUrl($nodeId) {
    return "$ProxyBase/node/$nodeId"
}

function Get-DirectNodeUrl($nodeId) {
    $port = 8000 + [int]$nodeId
    return "http://localhost:$port"
}

function Wait-HttpReadyProxy($nodeId, $timeoutSec = 30) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            Invoke-RestMethod -Method GET "$(Get-NodeBaseUrl $nodeId)/status" -TimeoutSec 2 | Out-Null
            return
        } catch {
            Start-Sleep -Seconds 1
        }
    }

    throw "Proxy path for node $nodeId did not become ready within $timeoutSec seconds"
}

function Wait-HttpReadyDirect($nodeId, $timeoutSec = 30) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            Invoke-RestMethod -Method GET "$(Get-DirectNodeUrl $nodeId)/status" -TimeoutSec 2 | Out-Null
            return
        } catch {
            Start-Sleep -Seconds 1
        }
    }

    throw "Service for node $nodeId did not become ready within $timeoutSec seconds"
}

function Wait-HttpReady($nodeId, $timeoutSec = 30) {
    Wait-HttpReadyDirect $nodeId $timeoutSec
}

function Get-Poll-Direct($nodeId, $poll) {
    Invoke-RestMethod "$(Get-DirectNodeUrl $nodeId)/poll/$poll"
}